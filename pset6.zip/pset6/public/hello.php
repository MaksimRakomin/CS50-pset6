<!DOCTYPE html>

<html>
    <head>
        <title>hello</title>
    </head>
    <body>
        hello, <?= htmlspecialchars($_GET["name"]) ?>
    </body>
</html>
